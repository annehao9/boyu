//加载Express模块
const express=require('express');
//加载MySQL模块
const mysql=require('mysql');
//加载bodyParser模块
const bodyParser=require('body-parser');
//加载MD5模块
const md5=require('md5');
//创建MySQL连接池
const pool=mysql.createPool({
    host:'127.0.0.1',
    port:3306,
    user:'root',
    password:'',
    database:'minsu',
    connectionLimit:20,
    charset:'utf8'
});
//创建服务器对象
const server=express();
server.use(bodyParser.urlencoded({
    extended:false
}));

//加载CORS模块
const cors=require('cors');
//使用CORS中间件
server.use(cors({
    origin:['http://localhost:8080','http://127.0.0.1:8080']
}));
//用户注册接口
server.post('/register',(req,res)=>{
    //获取用户名和密码信息
    let username=req.body.username;
    let password=req.body.password;
    //以username为条件进行查找操作，以保证用户名的唯一性
    let sql='SELECT COUNT(id) AS COUNT FROM minsu_user WHERE user_name=?';
    pool.query(sql,[username],(error,results)=>{
        if(error) throw error;
        let count=results[0].count;
        if(count==0){
            //将用户的相关信息插入到数据表
            //头像
            let avatar='00adca5a0d93daa80121985c9ef05f.jpg';
            sql='INSERT minsu_user(user_name,user_password,user_vatar) VALUES(?,MD5(?),?)';
            pool.query(sql,[username,password,avatar],
            (error,results)=>{
                if(error) throw error;
                res.send({message:'ok',code:200});
                })
        }else{
            res.send({message:'usr exists',code:201});
        } 
    });
});

//用户登录接口, 并返回此用户的订单表信息
server.post('/login',(req,res)=>{
    //获取用户名和密码信息
    let username=req.body.username;
    let password=req.body.password;
    //查询SQL语句
    
    let sql='SELECT a.id,a.user_name,a.user_vatar,b.id,b.roomid,b.orderstate,b.price,b.ordertime,b.intime,b.outtime,b.remark,b.residentsid FROM minsu_user as a LEFT JOIN minsu_orders as b ON a.id=b.uid WHERE a.user_name=? AND a.user_password=MD5(?)';
    pool.query(sql,[username,password],(error,results)=>{
        if (error) throw error;
        if(results.length==0){
            //判断有无登录信息
            let sql='SELECT count(id),user_name,user_vatar FROM minsu_user WHERE user_name=? AND user_password=MD5(?)';
            pool.query(sql,[username,password],(err,result)=>{
                if (error) throw error;
                if(result==0){
                    res.send({message:'login failed',code:201});
                }else{
                    res.send({message:'ok',code:205,result:result});
                }
            })
              
        }else{
            res.send({message:'ok',code:200,result:results});
        }
    });
});

//获取客房信息的接口需要传入城市，以及页数，并返回房东信息表
server.get('/roominfo',(req,res)=>{
    //获取地址栏中的id参数
    let city = req.query.city;  
    // 获取客户端传递的page参数
    let page = req.query.page? req.query.page : 1;

    // 存储每页显示的记录数
    let pagesize = 20;

    // 通过公式来计算从第几条记录开始返回
    let offset = (page - 1) * pagesize;

    // 用于存储获取到的总记录数
    let rowcount;
    // 获取指定分类下的文章总数
    let sql = 'SELECT COUNT(id) AS count FROM minsu_roominfo WHERE city=?';

    pool.query(sql, [city], (error, results) => {
    if (error) throw error;
    // 将获取到总记录数赋给rowcount变量
    rowcount = results[0].count;
    // 根据总记录数和每页显示的记录数来计算总页数
    let pagecount = Math.ceil(rowcount / pagesize);
    /*******************************************/
    //SQL语句
    let sql='SELECT a.roomtitle,a.id,a.ratednum,a.bednum,a.remark,a.roomdescription,a.roominfo_status,a.landladyid,a.price,a.city,a.pic,b.name,b.introduce,b.vatar FROM minsu_roominfo as a LEFT JOIN minsu_landlady as b on a.landladyid=b.id WHERE a.city=? LIMIT ?,?';
    // 执行SQL查询
  pool.query(sql, [city,offset,pagesize], (error, results) => {
    if (error) throw error;
    // 返回数据到客户端
    res.send({ message: 'ok', code: 200, result: results, pagecount: pagecount});
  });
});
});

//插入订单信息表，需要传入订单列所有的信息
server.post('/orders',(req,res)=>{
    let obj=req.body;
    let sql='insert into minsu_orders set ?';
     //1.3执行SQL命令，将数据插入到数据表
    pool.query(sql,[obj],(err,result)=>{
        if(err){
        // console.log(err);
        res.send({code:500,msg:'订单失败'});
        return;
        }
        res.send({code:200,msg:'订单成功'});
    });
 });

//评论表，有订单才可以评论
server.post('/comm',(req,res)=>{
    let obj=req.body;
    let sql='SELECT COUNT(id) FROM minsu_orders WHERE id=? ';
    pool.query(sql,[obj.roomid],(err,result)=>{
        if(err) throw err;
        if(result==0){
            return
        }else{
            let sql='INSERT INTO minsu_comm SET ?';
            pool.query(sql,[obj],(err,result)=>{
                if(err){
                    res.send({code:500,msg:'评论失败'});
                    return;
                }
                res.send({code:200,msg:'评论成功'});

            })

        }
    })
});

//评论表查询
server.get('/comms',(req,res)=>{
       let  roomid = req.query.roomid;
       let sql='SELECT COUNT(id),commtext,remark FROM minsu_comm WHERE roomid=?';
       pool.query(sql,[roomid],(err,result)=>{
        if(err) throw err;
        if(result==0){
            return;
        }
        res.send({message:'ok',code:200,result:result});
       })
})


//指定服务器对象监听的端口号
server.listen(3000,()=>{
    console.log('server is running...');
})
